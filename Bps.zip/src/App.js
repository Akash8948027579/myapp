import Home from './Components/Home';
import Dashboard from './Components/Dashboard'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SignUp from './Components/SignUp';
import About from './Components/About';
import Background from './Components/Background';
import Table from './Components/Table';
import { DashboardCustomize } from '@mui/icons-material';
import Bpsbooking from './Components/Bpsbooking';
import MyComponent from './Components/MyCompnent';
import Bpsbooking2 from './Components/Bpsbooking2';
import Bpsbooking3 from './Components/Bpsbooking3';
import Drawer from './Components/ResponsiveDrawer';
import ResponsiveDrawer from './Components/ResponsiveDrawer';
import Bpsbooking1 from './Components/Bpsbooking1';




function App() {
  return (
    <>
    <Bpsbooking3/>
    
    </>
  );
}

export default App;