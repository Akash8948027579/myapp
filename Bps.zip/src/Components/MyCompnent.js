import React from 'react';
import { useTheme } from '@mui/material/styles';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import ResponsiveDrawer from './ResponsiveDrawer';

const MyComponent = () => {
  const theme = useTheme();

  return (
    <Container maxWidth="lg">
      {/* <Box sx={{width:'100%',height:'100%', border:'1px solid green',flexDirection:{xs:'column', md:'row'} }}>
        <Box sx={{width:'30%', height:'60%', background:'aqua', border:'1px solid gray', margin:'30px'}}>A while ago, in an interview with indianexpress.com he shared how he’s remained free of being tagged as a comedy actor or a villain even after portraying several roles in these categories. He said, “It is a very conscious and deliberate decision..I never say that I am a villain or a comedian, I say I am an actor and I can do different types of roles. Once you brand yourself then people are ready with their labels, they will stick it on you. But I am an actor, why should I brand myself, put myself in a cage?”</Box>
        <Box sx={{width:'30%', height:'60%', background:'aqua', border:'1px solid gray', margin:'30px'}}>A while ago, in an interview with indianexpress.com he shared how he’s remained free of being tagged as a comedy actor or a villain even after portraying several roles in these categories. He said, “It is a very conscious and deliberate decision..I never say that I am a villain or a comedian, I say I am an actor and I can do different types of roles. Once you brand yourself then people are ready with their labels, they will stick it on you. But I am an actor, why should I brand myself, put myself in a cage?”</Box>
        <Box sx={{width:'30%', height:'60%', background:'aqua', border:'1px solid gray', margin:'30px'}}>A while ago, in an interview with indianexpress.com he shared how he’s remained free of being tagged as a comedy actor or a villain even after portraying several roles in these categories. He said, “It is a very conscious and deliberate decision..I never say that I am a villain or a comedian, I say I am an actor and I can do different types of roles. Once you brand yourself then people are ready with their labels, they will stick it on you. But I am an actor, why should I brand myself, put myself in a cage?”</Box>
      </Box> */}
      <ResponsiveDrawer/>
    </Container>
  );
};

export default MyComponent;
