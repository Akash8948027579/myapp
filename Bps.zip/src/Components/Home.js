import * as React from 'react';
import Button from '@mui/material/Button';

function Home() {
  return (
    <>
    <h3>Home page</h3>
  <Button variant="contained" href='/SignUp' >Click me</Button>
  </>
  );
}

export default Home;
