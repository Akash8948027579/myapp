import React from 'react'

const About = () => {
  return (
    <div>
    This is About section.
    </div>
  
  )
}

export default About;
